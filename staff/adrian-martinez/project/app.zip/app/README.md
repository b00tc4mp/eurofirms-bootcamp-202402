# Aplicación Formative Live

Pataforma web para contactar recruitadores con estudiantes con el fin de favorecer la inserción laboral.

## Functional Descripction 

Este programa se va encargar de ayudar a la gente con la inserción laboral, demostrando aquellas áreas que se le da mejor con el fin de que las empresas puedan encontrar mejor lo que buscan.

El programa será un sitio web en donde va aparecer toda la información detallada de los estudios de un estudiante, sea un ciclo de FP como una carrera universitaria, y estas van ser secciones. En cada sección debe aparecer las asignaturas que tiene en un trimestre  la fecha (año). En donde se indicara asignatura y nota de los examenes o trabajos.
Para verificar sus notas el usuario va tener la opción de adjuntar una foto de su boletín académico.

El usuario va poder comentarios sobre sus notas o trabajos echos por trimeste en la sección de esos estudios.

La empresa va mirar con todo detalle aquellas secciones que le interesa de su currículun y va poder guardar el usuario en favoritos si le gusta su perfil para tenerlo a mano. Además si el usuario hace un cambio en su perfil le va a salir un punto amarillo en su "market" de la lista de favoritos para que vea sus últimos cambios.

### Functionalidades

- 









# Reglamentos de React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh
