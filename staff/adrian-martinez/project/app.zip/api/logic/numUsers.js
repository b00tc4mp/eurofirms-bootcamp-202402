//TODO
//Hacer función para devolver el número de usuarios registrados